//
//  HackApp.swift
//  Hack
//
//  Created by Gael Gaytan on 07/06/25.
//

import SwiftUI

@main
struct HackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
